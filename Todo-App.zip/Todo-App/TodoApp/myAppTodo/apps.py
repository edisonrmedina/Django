from django.apps import AppConfig


class MyapptodoConfig(AppConfig):
    name = 'myAppTodo'
