from django import forms
from .models import Tarea
class AggTarea(forms.ModelForm):

    class Meta:
        model = Tarea
        fields = ['tarea']


