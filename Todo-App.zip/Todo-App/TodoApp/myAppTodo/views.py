from django.shortcuts import render,redirect
from .models import Tarea
from .forms import AggTarea
# Create your views here.
tareas = []

def home(request):
    tareas = Tarea.objects.all()
    context = {'tareas':tareas}
    return render(request,'home.html',context)

def add(request):
    if request.method == 'POST':
        form = AggTarea(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = AggTarea()

    context = {'form':form}

    return render(request,'agregar.html',context)

def delete(request,idTarea):
    tarea = Tarea.objects.get(id =idTarea)
    tarea.delete()
    return redirect('home')

def edit(request, idTarea):
    tarea = Tarea.objects.get(id =idTarea)
    if request.method == 'POST':
        form = AggTarea(request.POST, instance=tarea)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = AggTarea(instance=tarea)

    context = {'form':form}

    return render(request,"edit.html",context)