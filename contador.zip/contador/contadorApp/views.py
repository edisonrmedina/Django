from django.shortcuts import render,redirect
from .models import Counter
# Create your views here.

def helloWorld(request):
    value = Counter.objects.filter(id = 1)[0]
    context = {'value':value}
    return render(request,'helloWorld.html',context)

def incrementar(request):
    obj = Counter.objects.filter(id=1)[0]
    obj.number = str(int(obj.number )+1)
    obj.save()
    return redirect('home')

def decre(request):
    obj = Counter.objects.filter(id=1)[0]
    obj.number = str(int(obj.number )-1)
    obj.save()
    #return redirect('home')
    return redirect(request.META['HTTP_REFERER'])

def resetear(request):
    obj = Counter.objects.filter(id = 1 )[0]
    obj.number = str(0)
    obj.save()
    return redirect('home')

def helloStudents(request):
    return  render(request,'helloStudent.html')
