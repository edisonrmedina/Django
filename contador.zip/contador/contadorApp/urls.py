from django.contrib import admin
from django.urls import path
from . import views


urlpatterns = [
    path('home/',views.helloWorld, name = 'home'),
    path('student/',views.helloStudents,name = 'student'),
    path('incr/',views.incrementar,name = 'incrementar'),
    path('decre/',views.decre,name = 'decrementar'),
    path('reset/',views.resetear,name = 'reset'),
]

