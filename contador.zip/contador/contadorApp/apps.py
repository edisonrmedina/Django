from django.apps import AppConfig


class ContadorappConfig(AppConfig):
    name = 'contadorApp'
